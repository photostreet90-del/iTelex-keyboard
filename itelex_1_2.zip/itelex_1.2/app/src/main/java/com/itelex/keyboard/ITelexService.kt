package com.itelex.keyboard

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout

class ITelexService : InputMethodService(), KeyboardView.Listener {

    companion object {
        /** Chữ nhận diện được từ micro, chờ chèn khi bàn phím hiện lại. */
        @Volatile var pendingText: String? = null
    }

    private lateinit var box: FrameLayout
    private lateinit var emoji: EmojiView
    private lateinit var kb: KeyboardView
    private lateinit var suggester: Suggester
    private lateinit var macroManager: MacroManager
    private val engine = TelexEngine()
    private val smartTransformer = VietnameseSmartTransformer()

    private var viMode = true
    private var actionId = EditorInfo.IME_ACTION_NONE
    private var multiLine = false
    private var noSuggest = false
    private var fieldNoSuggest = false
    private var isSecureField = false
    private var lastEdit = 0L
    private var lastGlobeTap = 0L

    override fun onCreate() {
        super.onCreate()
        suggester = Suggester(this)
        macroManager = MacroManager(this)
    }

    override fun onCreateInputView(): View {
        kb = KeyboardView(this)
        kb.applyUserSettings(
            KeyboardSettings.keyScale(this),
            KeyboardSettings.keyLift(this),
            KeyboardSettings.isSuggestEnabled(this),
            KeyboardSettings.keyWidth(this)
        )
        kb.listener = this
        kb.viMode = viMode

        emoji = EmojiView(this)
        emoji.visibility = View.GONE
        emoji.listener = object : EmojiView.Listener {
            override fun onEmoji(s: String) {
                val ic = currentInputConnection ?: return
                finishWord()
                ic.commitText(s, 1)
                after()
            }

            override fun onBack() = hideEmoji()
            override fun onDelete() = this@ITelexService.onDelete()
        }

        box = FrameLayout(this)
        box.addView(kb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(emoji, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return box
    }

    private fun showEmoji() {
        emoji.bottomPad = kb.bottomSpace()
        emoji.refresh()
        emoji.visibility = View.VISIBLE
        kb.visibility = View.INVISIBLE
    }

    private fun hideEmoji() {
        emoji.visibility = View.GONE
        kb.visibility = View.VISIBLE
    }

    private fun deliverPending() {
        val t = pendingText ?: return
        val ic = currentInputConnection ?: return
        pendingText = null
        var s = t.trim()
        if (s.isEmpty()) return
        val info = currentInputEditorInfo
        val caps = if (info != null) ic.getCursorCapsMode(info.inputType) else 0
        if (caps != 0 && s[0].isLowerCase()) s = s.replaceFirstChar { it.uppercaseChar() }
        val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        if (before.isNotEmpty() && !before.last().isWhitespace()) s = " $s"
        ic.commitText(s, 1)
        after()
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        engine.clear()
        val suggestEnabled = KeyboardSettings.isSuggestEnabled(this)

        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        multiLine = (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        actionId = info.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) actionId = EditorInfo.IME_ACTION_NONE

        val isPassword = cls == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
        val isEmailOrUri = cls == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                variation == InputType.TYPE_TEXT_VARIATION_URI)

        isSecureField = isPassword || isEmailOrUri
        fieldNoSuggest = isSecureField ||
            (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        noSuggest = fieldNoSuggest || !suggestEnabled

        if (::kb.isInitialized) {
            kb.applyUserSettings(
                KeyboardSettings.keyScale(this),
                KeyboardSettings.keyLift(this),
                suggestEnabled,
                KeyboardSettings.keyWidth(this)
            )
        }

        engine.telex = viMode && !isSecureField

        kb.page = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE)
            KeyboardView.Page.NUMBERS else KeyboardView.Page.LETTERS

        kb.returnLabel = when (actionId) {
            EditorInfo.IME_ACTION_GO -> "Đi"
            EditorInfo.IME_ACTION_SEARCH -> "Tìm"
            EditorInfo.IME_ACTION_SEND -> "Gửi"
            EditorInfo.IME_ACTION_NEXT -> "Tiếp"
            EditorInfo.IME_ACTION_DONE -> "Xong"
            else -> ""
        }
        kb.returnBlue = actionId == EditorInfo.IME_ACTION_GO ||
            actionId == EditorInfo.IME_ACTION_SEARCH ||
            actionId == EditorInfo.IME_ACTION_SEND
        kb.viMode = viMode
        kb.shiftState = 0
        hideEmoji()
        autoShift()
        refreshSuggestions()
        deliverPending()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        engine.clear()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (SystemClock.uptimeMillis() - lastEdit < 150L) return
        if (!engine.isEmpty &&
            (candidatesStart == -1 || newSelStart < candidatesStart || newSelStart > candidatesEnd)
        ) {
            engine.clear()
            refreshSuggestions()
        }
    }

    // --------------------------------------------------------------- tiện ích

    private fun composing() {
        val ic = currentInputConnection ?: return
        if (engine.isEmpty) ic.commitText("", 1) else ic.setComposingText(engine.text, 1)
    }

    /** Chốt từ đang gõ, áp dụng Smart Transform & mở rộng gõ tắt (Macro) nếu bật. */
    private fun finishWord(learn: Boolean = true, applyMacro: Boolean = true) {
        if (engine.isEmpty) return
        val rawWord = engine.text
        val ic = currentInputConnection
        val expanded = if (applyMacro && !isSecureField && KeyboardSettings.isMacroEnabled(this)) {
            macroManager.expand(rawWord)
        } else {
            null
        }
        if (expanded != null && ic != null) {
            ic.commitText(expanded, 1)
            if (learn && !noSuggest) suggester.learn(expanded)
        } else {
            val finalWord = if (viMode && !isSecureField && KeyboardSettings.isSmartTransformEnabled(this)) {
                smartTransformer.transform(rawWord)
            } else {
                rawWord
            }
            if (finalWord != rawWord && ic != null) {
                engine.replaceWith(finalWord)
                ic.setComposingText(engine.text, 1)
                ic.finishComposingText()
                if (learn && !noSuggest) suggester.learn(engine.text)
            } else {
                ic?.finishComposingText()
                if (learn && !noSuggest) suggester.learn(rawWord)
            }
        }
        engine.clear()
    }

    private fun autoShift() {
        if (kb.shiftState == 2 || kb.page != KeyboardView.Page.LETTERS) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        if (info.inputType == InputType.TYPE_NULL) return
        kb.shiftState = if (ic.getCursorCapsMode(info.inputType) != 0) 1 else 0
    }

    private fun refreshSuggestions() {
        if (!::kb.isInitialized) return
        kb.suggestions = if (noSuggest || !KeyboardSettings.isSuggestEnabled(this)) {
            emptyList()
        } else {
            suggester.suggest(engine.text, viMode)
        }
    }

    private fun after() {
        lastEdit = SystemClock.uptimeMillis()
        lastGlobeTap = 0L // gõ phím khác thì lần bấm địa cầu kế tiếp tính là lần 1
        autoShift()
        refreshSuggestions()
    }

    // --------------------------------------------------------------- Listener

    override fun onText(s: String, alt: Boolean) {
        val ic = currentInputConnection ?: return
        if (s.length == 1 && s[0].isLetter()) {
            if (alt) engine.feedLiteral(s[0]) else engine.feed(s[0])
            composing()
        } else {
            // Mở rộng gõ tắt ngay cả khi kết thúc từ bằng dấu câu (.,!?;:)
            finishWord(learn = true, applyMacro = true)
            ic.commitText(s, 1)
        }
        after()
    }

    override fun onDelete() {
        val ic = currentInputConnection ?: return
        if (!engine.isEmpty) {
            engine.backspace()
            composing()
        } else {
            val sel = ic.getSelectedText(0)
            if (!sel.isNullOrEmpty()) ic.commitText("", 1)
            else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        after()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        if (engine.isEmpty) {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                after()
                return
            }
        }
        finishWord(learn = true, applyMacro = true)
        ic.commitText(" ", 1)
        after()
    }

    override fun onReturn() {
        val ic = currentInputConnection ?: return
        finishWord(learn = true, applyMacro = true)
        if (actionId != EditorInfo.IME_ACTION_NONE && actionId != EditorInfo.IME_ACTION_UNSPECIFIED && !multiLine) {
            ic.performEditorAction(actionId)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        after()
    }

    /**
     * Phím Quả địa cầu:
     * - Bấm lần 1: đổi Tiếng Việt <-> English
     * - Bấm lần 2 (chưa gõ phím nào khác, trong vòng 2,5 giây): mở bảng Emoji,
     *   ngôn ngữ được trả về như trước khi bấm lần 1 (bấm ABC để quay lại bàn phím chữ)
     */
    override fun onGlobeClick() {
        finishWord(learn = true, applyMacro = false)
        val now = SystemClock.uptimeMillis()
        val second = lastGlobeTap != 0L && now - lastGlobeTap < 2500L
        viMode = !viMode
        engine.telex = viMode && !isSecureField
        kb.viMode = viMode
        refreshSuggestions()
        if (second) {
            lastGlobeTap = 0L
            showEmoji()
        } else {
            lastGlobeTap = now
        }
    }

    /** Nút "Aa" trên phím Q: bật / tắt thanh gợi ý từ ngay trên bàn phím. */
    override fun onToggleSuggest() {
        val on = !KeyboardSettings.isSuggestEnabled(this)
        KeyboardSettings.save(
            this,
            KeyboardSettings.keyScale(this),
            KeyboardSettings.keyLift(this),
            suggestEnabled = on
        )
        noSuggest = fieldNoSuggest || !on
        kb.applyUserSettings(
            KeyboardSettings.keyScale(this),
            KeyboardSettings.keyLift(this),
            on,
            KeyboardSettings.keyWidth(this)
        )
        refreshSuggestions()
    }

    override fun onMic() {
        finishWord()
        VoiceActivity.vietnamese = viMode
        val i = Intent(this, VoiceActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(i)
    }

    override fun onPickIme() {
        finishWord()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun onSuggestion(s: String) {
        val ic = currentInputConnection ?: return
        if (!engine.isEmpty) {
            ic.commitText(s, 1)
            if (!noSuggest) suggester.learn(s)
            engine.clear()
        } else {
            ic.commitText(s, 1)
        }
        ic.commitText(" ", 1)
        after()
    }
}
