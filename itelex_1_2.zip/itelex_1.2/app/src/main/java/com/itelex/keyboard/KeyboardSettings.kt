package com.itelex.keyboard

import android.content.Context

/** Lưu các tùy chỉnh giao diện và tính năng bàn phím trên thiết bị. */
object KeyboardSettings {
    private const val PREFS = "keyboard_settings"
    private const val KEY_SCALE = "key_scale"
    private const val KEY_LIFT = "key_lift"
    private const val KEY_WIDTH = "key_width"
    private const val KEY_SUGGEST = "suggest_enabled"
    private const val KEY_MACRO = "macro_enabled"
    private const val KEY_SMART_TRANSFORM = "smart_transform_enabled"

    fun keyScale(context: Context): Float =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_SCALE, 1.0f)

    fun keyLift(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_LIFT, 0)

    /** Mức độ rộng phím 0..10 (0 = mặc định, 10 = rộng nhất: lề hai bên và khe giữa các phím hẹp nhất). */
    fun keyWidth(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_WIDTH, 0)

    fun isSuggestEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SUGGEST, true)

    fun isMacroEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_MACRO, true)

    fun isSmartTransformEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SMART_TRANSFORM, true)

    fun save(
        context: Context,
        scale: Float,
        lift: Int,
        suggestEnabled: Boolean = isSuggestEnabled(context),
        macroEnabled: Boolean = isMacroEnabled(context),
        smartTransformEnabled: Boolean = isSmartTransformEnabled(context),
        keyWidth: Int = keyWidth(context)
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(KEY_SCALE, scale.coerceIn(0.85f, 1.4f))
            .putInt(KEY_LIFT, lift.coerceIn(0, 48))
            .putInt(KEY_WIDTH, keyWidth.coerceIn(0, 10))
            .putBoolean(KEY_SUGGEST, suggestEnabled)
            .putBoolean(KEY_MACRO, macroEnabled)
            .putBoolean(KEY_SMART_TRANSFORM, smartTransformEnabled)
            .apply()
    }
}
