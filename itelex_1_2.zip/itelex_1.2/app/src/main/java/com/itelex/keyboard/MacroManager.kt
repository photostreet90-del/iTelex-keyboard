package com.itelex.keyboard

import android.content.Context

/** Quản lý từ điển gõ tắt (Macro) giống UniKey, lưu cục bộ trên máy. */
class MacroManager(context: Context) {
    private val prefs = context.getSharedPreferences("itelex_macros", Context.MODE_PRIVATE)

    init {
        if (!prefs.getBoolean("_initialized", false)) {
            prefs.edit()
                .putBoolean("_initialized", true)
                .putString("vn", "Việt Nam")
                .putString("hn", "Hà Nội")
                .putString("hcm", "Hồ Chí Minh")
                .putString("dc", "được")
                .putString("ko", "không")
                .putString("k", "không")
                .putString("cx", "cũng")
                .putString("ng", "người")
                .putString("nc", "nước")
                .putString("tks", "cảm ơn")
                .apply()
        }
    }

    fun getAll(): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((k, v) in prefs.all) {
            if (k != "_initialized" && v is String) {
                out[k] = v
            }
        }
        return out
    }

    fun save(shortcut: String, expansion: String) {
        val key = shortcut.trim().lowercase()
        val valStr = expansion.trim()
        if (key.isEmpty() || valStr.isEmpty()) return
        prefs.edit().putString(key, valStr).apply()
    }

    fun remove(shortcut: String) {
        prefs.edit().remove(shortcut.trim().lowercase()).apply()
    }

    /** Mở rộng từ gõ tắt và tự giữ kiểu viết hoa (VN -> VIỆT NAM, Vn -> Việt Nam). */
    fun expand(word: String): String? {
        if (word.isEmpty()) return null
        val target = prefs.getString(word.lowercase(), null) ?: return null
        return when {
            word.length > 1 && word.all { it.isUpperCase() } -> target.uppercase()
            word[0].isUpperCase() -> target.replaceFirstChar { it.uppercaseChar() }
            else -> target
        }
    }
}
