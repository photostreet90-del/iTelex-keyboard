package com.itelex.keyboard

import android.content.Context
import java.text.Normalizer

private object Words {
    val VI = ("tôi|bạn|anh|chị|em|ông|bà|chúng tôi|chúng ta|họ|của|và|là|có|không|được|này|đó|cho|với|một|" +
        "những|các|để|trong|khi|đã|sẽ|đang|rất|cũng|nhưng|nếu|vì|nên|thì|mà|ở|đi|đến|về|ra|vào|lên|xuống|" +
        "làm|nói|biết|thấy|muốn|cần|phải|nhớ|yêu|thích|ăn|uống|ngủ|học|làm việc|công việc|gia đình|bạn bè|" +
        "hôm nay|ngày mai|hôm qua|bây giờ|buổi sáng|buổi tối|xin chào|cảm ơn|xin lỗi|không sao|tạm biệt|" +
        "chúc mừng|vui vẻ|hẹn gặp lại|ngày|tháng|năm|giờ|phút|người|nhà|trường|công ty|điện thoại|" +
        "máy tính|tiền|đẹp|tốt|xấu|lớn|nhỏ|nhiều|ít|mới|cũ|đúng|sai|thật|luôn|lại|còn|như|vậy|thế|sao|gì|" +
        "đâu|ai|bao nhiêu|bao giờ|tại sao|thế nào|Việt Nam|Hà Nội|Sài Gòn|Thanh Hóa|chào|được rồi|" +
        "đang làm gì|ăn cơm chưa|ngủ ngon|chúc ngủ ngon|mình|tụi mình|nhé|nha|ạ|à|ơi|vâng|dạ|hay|hoặc|" +
        "cùng|sau|trước|giữa|trên|dưới|bên|ngoài|đây|kia|nào|thôi|nữa|đều|chỉ|rồi|chưa|vẫn|từ|tới|theo|" +
        "bằng|qua|giúp|gửi|nhận|xem|nghe|đọc|viết|chơi|đợi|chờ|gặp|hỏi|trả lời|tìm|mua|bán|trả").split('|')

    val EN = ("the|and|you|that|have|for|not|with|this|but|from|they|will|would|there|their|what|about|which|" +
        "when|make|can|like|time|just|know|take|people|into|year|your|good|some|could|them|see|other|than|" +
        "then|now|look|only|come|its|over|think|also|back|after|use|two|how|our|work|first|well|way|even|new|" +
        "want|because|any|these|give|day|most|hello|thanks|thank you|please|sorry|okay|great|yes|no|I'm|I'll|" +
        "don't|it's|can't|tomorrow|today|tonight|morning|night|friend|home|love|phone|message|call|meeting|" +
        "later|soon|where|why|who|going|doing|really|right|still|need|should|where|here|been|being|were|was|" +
        "are|is|am|do|did|does|has|had|get|got|let|put|say|said|tell|told|ask|asked|try|keep|help|talk|feel").split('|')

    val VI_START = listOf("tôi", "bạn", "cảm ơn")
    val EN_START = listOf("I", "The", "Thanks")
}

/** Gợi ý từ: danh sách có sẵn + các từ người dùng hay gõ (lưu cục bộ trên máy). */
class Suggester(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("itelex_learned", Context.MODE_PRIVATE)

    fun learn(word: String) {
        if (!KeyboardSettings.isSuggestEnabled(ctx)) return
        val w = word.lowercase()
        if (w.length < 2 || w.any { !it.isLetter() }) return
        val key = "w_$w"
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    /** Trả về tối đa 3 gợi ý. Ô đầu là chính từ đang gõ. */
    fun suggest(prefix: String, vi: Boolean): List<String> {
        if (!KeyboardSettings.isSuggestEnabled(ctx)) return emptyList()
        if (prefix.isEmpty()) return if (vi) Words.VI_START else Words.EN_START
        val lp = prefix.lowercase()
        val sp = strip(lp)
        val found = LinkedHashSet<String>()

        prefs.all.entries
            .filter { it.key.startsWith("w_") }
            .map { it.key.substring(2) to ((it.value as? Int) ?: 0) }
            .sortedByDescending { it.second }
            .forEach { if (strip(it.first).startsWith(sp)) found.add(it.first) }

        (if (vi) Words.VI else Words.EN).forEach {
            if (strip(it.lowercase()).startsWith(sp)) found.add(it)
        }

        val out = ArrayList<String>()
        out.add(prefix)
        for (w in found) {
            if (out.size >= 3) break
            val shown = matchCase(prefix, w)
            if (out.none { it.equals(shown, ignoreCase = true) }) out.add(shown)
        }
        return out
    }

    private fun matchCase(prefix: String, w: String): String = when {
        prefix.length > 1 && prefix.all { it.isUpperCase() } -> w.uppercase()
        prefix[0].isUpperCase() -> w.replaceFirstChar { it.uppercaseChar() }
        else -> w
    }

    private fun strip(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace('đ', 'd')
}
