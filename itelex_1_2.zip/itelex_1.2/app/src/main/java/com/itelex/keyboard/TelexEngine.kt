package com.itelex.keyboard

import java.text.Normalizer

/**
 * Bộ gõ Telex: giữ từ đang gõ và tự biến đổi dấu / mũ khi nhận phím.
 * Không phụ thuộc Android nên có thể kiểm thử riêng.
 */
class TelexEngine {
    /** false = gõ thẳng, không biến đổi (chế độ tiếng Anh). */
    var telex = true

    private val word = StringBuilder()

    val text: String get() = word.toString()
    val isEmpty: Boolean get() = word.isEmpty()

    fun clear() {
        word.setLength(0)
    }

    fun replaceWith(newText: String) {
        word.setLength(0)
        word.append(newText)
        if (telex) retone()
    }

    fun backspace() {
        if (word.isNotEmpty()) {
            word.setLength(word.length - 1)
            if (telex) retone()
        }
    }

    /** Chèn nguyên văn một ký tự (ví dụ chọn "ả" từ bảng nhấn giữ). */
    fun feedLiteral(ch: Char) {
        word.append(ch)
        if (telex) retone()
    }

    fun feed(ch: Char) {
        if (!telex) {
            word.append(ch)
            return
        }
        if (!transform(ch)) word.append(ch)
        retone()
    }

    // ---------------------------------------------------------------- nội bộ

    private companion object {
        const val NONE = '\u0000'
        const val CIRC = '̂'
        const val BREVE = '̆'
        const val HORN = '̛'
        const val GRAVE = '̀'
        const val ACUTE = '́'
        const val HOOK = '̉'
        const val TILDE = '̃'
        const val DOT = '̣'
        const val VOWELS = "aeiouy"
    }

    private data class P(val base: Char, val mod: Char, val tone: Char, val upper: Boolean)

    private fun split(c: Char): P {
        val upper = c.isUpperCase()
        val d = Normalizer.normalize(c.toString().lowercase(), Normalizer.Form.NFD)
        var mod = NONE
        var tone = NONE
        for (i in 1 until d.length) {
            when (d[i]) {
                CIRC, BREVE, HORN -> mod = d[i]
                GRAVE, ACUTE, HOOK, TILDE, DOT -> tone = d[i]
            }
        }
        return P(d[0], mod, tone, upper)
    }

    private fun join(p: P): Char {
        if (p.base == 'đ') return if (p.upper) 'Đ' else 'đ'
        val sb = StringBuilder().append(p.base)
        if (p.mod != NONE) sb.append(p.mod)
        if (p.tone != NONE) sb.append(p.tone)
        val r = Normalizer.normalize(sb.toString(), Normalizer.Form.NFC)[0]
        return if (p.upper) r.uppercaseChar() else r
    }

    private fun isVowel(c: Char) = split(c).base in VOWELS

    private fun nearestVowel(): Int {
        for (i in word.length - 1 downTo 0) if (isVowel(word[i])) return i
        return -1
    }

    private fun transform(ch: Char): Boolean = when (ch.lowercaseChar()) {
        'd' -> doD()
        'o' -> doO(ch)
        'a', 'e' -> doCirc(ch.lowercaseChar())
        'w' -> doW(ch)
        's' -> doTone(ACUTE)
        'f' -> doTone(GRAVE)
        'r' -> doTone(HOOK)
        'x' -> doTone(TILDE)
        'j' -> doTone(DOT)
        'z' -> doTone(NONE)
        else -> false
    }

    /** dd -> đ ; ddd -> dd */
    private fun doD(): Boolean {
        if (word.isEmpty()) return false
        val i = word.length - 1
        return when (word[i]) {
            'd' -> { word.setCharAt(i, 'đ'); true }
            'D' -> { word.setCharAt(i, 'Đ'); true }
            'đ' -> { word.setCharAt(i, 'd'); false }
            'Đ' -> { word.setCharAt(i, 'D'); false }
            else -> false
        }
    }

    /** ư + o -> ươ (không cần gõ thêm w cho o); các trường hợp khác giống oo -> ô. */
    private fun doO(ch: Char): Boolean {
        if (word.isNotEmpty()) {
            val last = split(word[word.length - 1])
            if (last.base == 'u' && last.mod == HORN) {
                word.append(if (ch.isUpperCase()) 'Ơ' else 'ơ')
                return true
            }
        }
        return doCirc('o')
    }

    /** aa -> â, ee -> ê, oo -> ô ; gõ lần 3 thì hoàn tác. */
    private fun doCirc(lc: Char): Boolean {
        val i = nearestVowel()
        if (i < 0) return false
        val p = split(word[i])
        if (p.base != lc) return false
        if (p.mod == CIRC) {
            word.setCharAt(i, join(p.copy(mod = NONE)))
            return false
        }
        word.setCharAt(i, join(p.copy(mod = CIRC)))
        return true
    }

    /** aw -> ă, ow -> ơ, uw -> ư, uow -> ươ, w đầu từ hoặc sau phụ âm -> ư */
    private fun doW(ch: Char): Boolean {
        if (word.isEmpty()) {
            word.append(if (ch.isUpperCase()) 'Ư' else 'ư')
            return true
        }
        if (word.length == 1 && (word[0] == 'ư' || word[0] == 'Ư')) {
            word.setCharAt(0, if (word[0] == 'Ư') 'W' else 'w')
            return true
        }
        val i = nearestVowel()
        if (i < 0) {
            // phụ âm + w -> phụ âm + ư (nhw -> như, nhwng -> nhưng)
            word.append(if (ch.isUpperCase()) 'Ư' else 'ư')
            return true
        }
        val p = split(word[i])
        when (p.base) {
            'a' -> {
                if (p.mod == BREVE) {
                    word.setCharAt(i, join(p.copy(mod = NONE)))
                    return false
                }
                word.setCharAt(i, join(p.copy(mod = BREVE)))
                return true
            }
            'o', 'u' -> {
                // Đã là "ươ" rồi thì w thừa (kiểu uwow) không làm gì, tránh hoàn tác nhầm
                if (p.base == 'o' && p.mod == HORN && i > 0) {
                    val q0 = split(word[i - 1])
                    if (q0.base == 'u' && q0.mod == HORN) return true
                }
                if (p.mod == HORN) {
                    word.setCharAt(i, join(p.copy(mod = NONE)))
                    return false
                }
                word.setCharAt(i, join(p.copy(mod = HORN)))
                if (p.base == 'o' && i > 0) {
                    val q = split(word[i - 1])
                    val afterQ = i >= 2 && word[i - 2].lowercaseChar() == 'q'
                    if (q.base == 'u' && q.mod != CIRC && !afterQ) {
                        word.setCharAt(i - 1, join(q.copy(mod = HORN)))
                    }
                }
                return true
            }
            // nguoi + w -> ngươi, tuoi + w -> tươi (w đến muộn sau nguyên âm cuối)
            else -> return hornUoCluster(i)
        }
    }

    /** Tìm cụm "uo" liền trước nguyên âm ở vị trí [end] rồi thêm móc cho cả hai (ươ). */
    private fun hornUoCluster(end: Int): Boolean {
        var j = end - 1
        while (j > 0 && isVowel(word[j])) {
            val o = split(word[j])
            val u = split(word[j - 1])
            if (o.base == 'o' && o.mod == NONE && u.base == 'u' && u.mod == NONE) {
                if (j >= 2 && word[j - 2].lowercaseChar() == 'q') return false
                word.setCharAt(j, join(o.copy(mod = HORN)))
                word.setCharAt(j - 1, join(u.copy(mod = HORN)))
                return true
            }
            j--
        }
        return false
    }

    /** s f r x j z : đặt / đổi / xoá dấu thanh. */
    private fun doTone(tone: Char): Boolean {
        if (toneIndex() < 0) return false
        val cur = currentTone()
        if (tone == NONE) {
            if (cur == NONE) return false
            applyTone(NONE)
            return true
        }
        if (cur == tone) {
            applyTone(NONE)
            return false // hoàn tác: ký tự phím được chèn nguyên văn
        }
        return applyTone(tone)
    }

    private fun currentTone(): Char {
        for (c in word) {
            val t = split(c).tone
            if (t != NONE) return t
        }
        return NONE
    }

    private fun applyTone(tone: Char): Boolean {
        for (i in word.indices) {
            val p = split(word[i])
            if (p.tone != NONE) word.setCharAt(i, join(p.copy(tone = NONE)))
        }
        if (tone == NONE) return true
        val idx = toneIndex()
        if (idx < 0) return false
        word.setCharAt(idx, join(split(word[idx]).copy(tone = tone)))
        return true
    }

    private fun retone() {
        val t = currentTone()
        if (t != NONE) applyTone(t)
    }

    /** Vị trí nguyên âm sẽ mang dấu thanh (kiểu cũ: hòa, thủy). -1 nếu không có. */
    private fun toneIndex(): Int {
        var i = 0
        while (i < word.length && !isVowel(word[i])) i++
        if (i >= word.length) return -1
        if (i > 0) {
            val prev = word[i - 1].lowercaseChar()
            val cur = split(word[i]).base
            if (prev == 'q' && cur == 'u') i++
            else if (prev == 'g' && cur == 'i' && i + 1 < word.length && isVowel(word[i + 1])) i++
        }
        val s = i
        var e = s
        while (e < word.length && isVowel(word[e])) e++
        if (e == s) return -1
        var lastMod = -1
        for (k in s until e) if (split(word[k]).mod != NONE) lastMod = k
        if (lastMod >= 0) return lastMod
        val n = e - s
        val hasFinal = e < word.length
        return when {
            n == 1 -> s
            n == 2 -> if (hasFinal) s + 1 else s
            else -> s + 1
        }
    }
}
