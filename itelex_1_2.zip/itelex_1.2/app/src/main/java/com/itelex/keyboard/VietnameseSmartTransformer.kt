package com.itelex.keyboard

import java.text.Normalizer

/**
 * Biến đổi thông minh (Smart Transform) kiểu Laban Key:
 * - Tự động sửa lỗi gõ trượt phím lân cận (Proximity Key Correction) ở cuối âm tiết tiếng Việt
 * - Sửa lỗi đảo thứ tự phím khi gõ nhanh hai ngón cái (Transposition Correction, vd: khnog -> không)
 * - Giữ nguyên chữ hoa/thường và dấu thanh hiện có của từ
 */
class VietnameseSmartTransformer {

    // Bản đồ phím lân cận trên bàn phím QWERTY
    private val adjacentKeys = mapOf(
        'n' to listOf('b', 'm', 'h', 'j'),
        'm' to listOf('n', 'j', 'k'),
        't' to listOf('r', 'y', 'g', 'f'),
        'c' to listOf('x', 'v', 'd', 'f'),
        'g' to listOf('f', 'h', 't', 'v', 'b'),
        'p' to listOf('o', 'l'),
        'h' to listOf('g', 'j', 'y', 'u', 'b', 'n'),
        // Các phím gõ nhầm phổ biến ở cuối từ -> phụ âm cuối hợp lệ
        'b' to listOf('n', 'g', 'm'),
        'v' to listOf('c', 'g'),
        'k' to listOf('m', 'o'),
        'l' to listOf('o', 'p'),
        'd' to listOf('c', 'e'),
        'y' to listOf('t', 'h')
    )

    // Phụ âm cuối hợp lệ trong tiếng Việt
    private val validEndConsonants = setOf("c", "ch", "m", "n", "ng", "nh", "p", "t")

    // Các tổ hợp phụ âm đầu hợp lệ
    private val validInitialClusters = setOf(
        "b", "c", "ch", "d", "đ", "g", "gh", "gi", "h", "k", "kh",
        "l", "m", "n", "ng", "ngh", "nh", "p", "ph", "qu", "r", "s", "t", "th", "tr", "v", "x"
    )

    // Bảng sửa nhanh các lỗi đảo phím kinh điển khi gõ tiếng Việt
    private val commonTranspositions = mapOf(
        "khnog" to "không",
        "khôgn" to "không",
        "khong" to "không",
        "ngưoi" to "người",
        "nguoi" to "người",
        "đưoc" to "được",
        "duoc" to "được",
        "trưoc" to "trước",
        "truoc" to "trước",
        "nhưgn" to "nhưng",
        "nhung" to "nhưng",
        "trogn" to "trong",
        "cũgn" to "cũng",
        "trog" to "trong",
        "nhữgn" to "những",
        "đã" to "đã",
        "vẫ" to "vẫn",
        "của" to "của",
        "viêt" to "viết",
        "tiêng" to "tiếng"
    )

    private fun stripAccents(s: String): String {
        val nfd = Normalizer.normalize(s, Normalizer.Form.NFD)
        return nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
            .replace('Đ', 'D')
    }

    private fun isVowel(c: Char): Boolean {
        val base = stripAccents(c.toString()).lowercase()
        return base.isNotEmpty() && base[0] in "aeiouy"
    }

    private fun preserveCase(original: String, transformed: String): String {
        if (original.isEmpty() || transformed.isEmpty()) return transformed
        if (original.all { it.isUpperCase() }) return transformed.uppercase()
        if (original[0].isUpperCase()) {
            return transformed.replaceFirstChar { it.uppercaseChar() }
        }
        return transformed
    }

    /**
     * Biến đổi thông minh từ đang gõ khi kết thúc từ (Space/Dấu câu) hoặc đang gõ lướt
     */
    fun transform(input: String): String {
        if (input.length < 2) return input
        val lower = input.lowercase()

        // 1. Kiểm tra bảng sửa lỗi đảo phím nhanh (giữ nguyên định dạng hoa/thường)
        commonTranspositions[lower]?.let { fixed ->
            return preserveCase(input, fixed)
        }

        // 2. Sửa lỗi đảo 2 ký tự liền kề ở phần đầu/cuối từ (vd: "khnog" -> "không", "trogn" -> "trong")
        val transposed = fixTransposition(lower)
        if (transposed != lower) {
            return preserveCase(input, transposed)
        }

        // 3. Sửa lỗi gõ trượt phím lân cận ở phụ âm cuối (vd: "nguyêb" -> "nguyên", "họv" -> "học")
        val proximityFixed = fixProximityEndConsonant(lower)
        if (proximityFixed != lower) {
            return preserveCase(input, proximityFixed)
        }

        return input
    }

    private fun fixTransposition(word: String): String {
        if (word.length < 3) return word

        // Trường hợp phổ biến: kết thúc bằng "gn" thay vì "ng" (vd: trogn -> trong, khôgn -> không)
        if (word.endsWith("gn") && word.length >= 3 && isVowel(word[word.length - 3])) {
            return word.dropLast(2) + "ng"
        }
        // Kết thúc bằng "hn" thay vì "nh" (vd: tihnh -> tinh, ahn -> anh)
        if (word.endsWith("hn") && word.length >= 3 && isVowel(word[word.length - 3])) {
            return word.dropLast(2) + "nh"
        }
        // Kết thúc bằng "hc" thay vì "ch" (vd: sahc -> sách, thihc -> thích)
        if (word.endsWith("hc") && word.length >= 3 && isVowel(word[word.length - 3])) {
            return word.dropLast(2) + "ch"
        }

        // Đảo phụ âm đầu + nguyên âm bị gõ ngược (vd: khnog -> khong)
        val chars = word.toCharArray()
        for (i in 1 until chars.size - 1) {
            if (!isVowel(chars[i]) && isVowel(chars[i + 1])) {
                // Kiểm tra xem sau khi đảo, cụm phụ âm đầu có hợp lệ không
                val prefixBefore = word.substring(0, i)
                val prefixAfter = word.substring(0, i + 1)
                if (prefixBefore in validInitialClusters && prefixAfter !in validInitialClusters) {
                    val tmp = chars[i]
                    chars[i] = chars[i + 1]
                    chars[i + 1] = tmp
                    val candidate = String(chars)
                    if (isValidVietnameseStructure(candidate)) {
                        return candidate
                    }
                    chars[i + 1] = chars[i]
                    chars[i] = tmp
                }
            }
        }
        return word
    }

    private fun fixProximityEndConsonant(word: String): String {
        if (word.length < 2) return word
        // Nếu từ hiện tại đã kết thúc bằng nguyên âm hoặc phụ âm cuối hợp lệ thì giữ nguyên
        val lastChar = word.last()
        if (isVowel(lastChar)) return word

        // Tách phần kết thúc sau nguyên âm cuối cùng
        var lastVowelIdx = -1
        for (i in word.length - 1 downTo 0) {
            if (isVowel(word[i])) {
                lastVowelIdx = i
                break
            }
        }
        if (lastVowelIdx < 0 || lastVowelIdx == word.length - 1) return word

        val stem = word.substring(0, lastVowelIdx + 1)
        val coda = word.substring(lastVowelIdx + 1)

        // Nếu phần đuôi đã hợp lệ (c, ch, m, n, ng, nh, p, t) thì không can thiệp
        if (coda in validEndConsonants) return word

        // Trường hợp đuôi 1 ký tự bị gõ trượt (vd: "nguyêb" -> coda = "b" -> "n" -> "nguyên")
        if (coda.length == 1) {
            val badChar = coda[0]
            val neighbors = adjacentKeys[badChar] ?: return word
            // Ưu tiên phụ âm cuối phổ biến: n, ng, m, t, c, p
            val priority = listOf('n', 'm', 't', 'c', 'p')
            val orderedNeighbors = neighbors.sortedBy { ch ->
                val idx = priority.indexOf(ch)
                if (idx >= 0) idx else 99
            }
            for (n in orderedNeighbors) {
                if (n.toString() in validEndConsonants) {
                    return stem + n
                }
            }
        }

        // Trường hợp đuôi 2 ký tự bị gõ trượt (vd: "nhưnb" -> "nhưng", "thàbh" -> "thành")
        if (coda.length == 2) {
            val c0 = coda[0]
            val c1 = coda[1]
            // Thử sửa ký tự thứ 2
            for (n1 in (adjacentKeys[c1] ?: emptyList())) {
                val cand = "$c0$n1"
                if (cand in validEndConsonants) return stem + cand
            }
            // Thử sửa ký tự thứ 1
            for (n0 in (adjacentKeys[c0] ?: emptyList())) {
                val cand = "$n0$c1"
                if (cand in validEndConsonants) return stem + cand
            }
        }

        return word
    }

    private fun isValidVietnameseStructure(word: String): Boolean {
        var i = 0
        while (i < word.length && !isVowel(word[i])) i++
        if (i == word.length) return false
        val initial = word.substring(0, i)
        if (initial.isNotEmpty() && initial !in validInitialClusters) return false
        while (i < word.length && isVowel(word[i])) i++
        val coda = word.substring(i)
        return coda.isEmpty() || coda in validEndConsonants
    }
}
