package com.itelex.keyboard

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Màn hình nhận diện giọng nói:
 * - Lần đầu: xin quyền micro (RECORD_AUDIO).
 * - Đã có quyền và máy có dịch vụ nhận diện: hiện biểu tượng micro phóng to đang thu âm
 *   (nhấp nháy theo âm lượng), hiện chữ nhận diện được ngay khi nói. Nói xong bấm vào micro để dừng.
 *   Bấm ra vùng tối bên ngoài hoặc phím Back để hủy.
 * - Bị từ chối quyền: mở hộp thoại giọng nói hệ thống (Google) không cần quyền.
 * - Máy không có dịch vụ nhận diện nào (thường gặp trên máy ảo): báo rõ bằng thông báo.
 */
class VoiceActivity : Activity() {

    companion object {
        /** true = nói tiếng Việt, false = tiếng Anh */
        @Volatile var vietnamese = true
    }

    private val reqSpeech = 1001
    private val reqPerm = 2001
    private var speechRecognizer: SpeechRecognizer? = null

    private var orb: MicOrb? = null
    private var statusText: TextView? = null
    private var transcript: TextView? = null
    private var stopped = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) {
            finish()
            return
        }
        if (hasAudioPermission()) {
            startRecognition()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqPerm)
        }
    }

    private fun hasAudioPermission() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqPerm) startRecognition()
    }

    private fun startRecognition() {
        if (hasAudioPermission() && SpeechRecognizer.isRecognitionAvailable(this)) {
            startDirectRecognition()
        } else {
            startSystemDialogRecognition()
        }
    }

    private fun buildRecognizerIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (vietnamese) "vi-VN" else "en-US")
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PROMPT, if (vietnamese) "Đang nghe…" else "Speak now…")
    }

    // ------------------------------------------------------------------ giao diện micro phóng to

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun buildListeningUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            setOnClickListener { cancelAndFinish() } // bấm vùng tối bên ngoài = hủy
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isClickable = true // chặn bấm nhầm vào chữ làm hủy
            setPadding(dp(24f).toInt(), 0, dp(24f).toInt(), 0)
        }
        val micOrb = MicOrb(this).apply {
            setOnClickListener { stopListeningNow() }
        }
        column.addView(micOrb, LinearLayout.LayoutParams(dp(220f).toInt(), dp(220f).toInt()))

        val titleView = TextView(this).apply {
            text = if (vietnamese) "Đang nghe…" else "Listening…"
            setTextColor(0xFFFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        column.addView(titleView, LinearLayout.LayoutParams(-2, -2))

        val hintView = TextView(this).apply {
            text = if (vietnamese) "Nói xong thì bấm vào micro để dừng" else "Tap the microphone when you're done"
            setTextColor(0xB3FFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            setPadding(0, dp(6f).toInt(), 0, dp(14f).toInt())
        }
        column.addView(hintView, LinearLayout.LayoutParams(-2, -2))

        val transcriptView = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            gravity = Gravity.CENTER
            maxLines = 4
        }
        column.addView(transcriptView, LinearLayout.LayoutParams(-2, -2))

        root.addView(column, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        setContentView(root)

        orb = micOrb
        statusText = titleView
        transcript = transcriptView
    }

    private fun stopListeningNow() {
        if (stopped) return
        stopped = true
        orb?.active = false
        orb?.isEnabled = false
        statusText?.text = if (vietnamese) "Đang xử lý…" else "Processing…"
        speechRecognizer?.stopListening()
    }

    private fun cancelAndFinish() {
        speechRecognizer?.cancel()
        finish()
    }

    // ------------------------------------------------------------------ nhận diện trực tiếp

    private fun startDirectRecognition() {
        buildListeningUi()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onEndOfSpeech() {
                    // Tự dừng khi im lặng: chuyển sang trạng thái xử lý
                    if (!stopped) {
                        stopped = true
                        orb?.active = false
                        orb?.isEnabled = false
                        statusText?.text = if (vietnamese) "Đang xử lý…" else "Processing…"
                    }
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val o = orb ?: return
                    val target = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    o.level = o.level * 0.6f + target * 0.4f
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) transcript?.text = partial
                }

                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            if (vietnamese) "Không nghe thấy giọng nói, hãy thử lại." else "Didn't catch that, try again."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Chưa cấp quyền micro cho iTelex."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Nhận diện giọng nói cần kết nối mạng."
                        else -> "Lỗi nhận diện giọng nói (mã $error)."
                    }
                    Toast.makeText(this@VoiceActivity, msg, Toast.LENGTH_LONG).show()
                    finish()
                }

                override fun onResults(results: Bundle?) {
                    val recognized = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!recognized.isNullOrBlank()) {
                        ITelexService.pendingText = recognized
                    }
                    finish()
                }
            })
            startListening(buildRecognizerIntent())
        }
    }

    // ------------------------------------------------------------------ hộp thoại hệ thống (dự phòng)

    private fun startSystemDialogRecognition() {
        try {
            startActivityForResult(buildRecognizerIntent(), reqSpeech)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "Máy chưa có dịch vụ nhận diện giọng nói (Google). Máy ảo thường không có, hãy thử trên điện thoại thật.",
                Toast.LENGTH_LONG
            ).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqSpeech && resultCode == RESULT_OK) {
            val recognized = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!recognized.isNullOrBlank()) {
                ITelexService.pendingText = recognized
            }
        }
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    // ------------------------------------------------------------------ biểu tượng micro phóng to

    /** Nút tròn có biểu tượng micro, vòng sóng nhấp nháy theo âm lượng khi đang thu âm. */
    private class MicOrb(context: Context) : View(context) {
        private val density = resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val arc = RectF()
        private val body = RectF()
        private var breathe = 0f

        /** Âm lượng 0..1 */
        var level = 0f
            set(value) {
                field = value
                invalidate()
            }

        /** true = đang thu âm (đỏ, có sóng), false = đã dừng (xám). */
        var active = true
            set(value) {
                field = value
                invalidate()
            }

        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                breathe = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            animator.start()
        }

        override fun onDetachedFromWindow() {
            animator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(c: Canvas) {
            val d = density
            val cx = width / 2f
            val cy = height / 2f
            val base = 50f * d
            val color = if (active) 0xFFFF3B30.toInt() else 0xFF8E8E93.toInt()
            val rgb = color and 0x00FFFFFF

            if (active) {
                paint.style = Paint.Style.FILL
                paint.color = rgb or 0x40000000
                c.drawCircle(cx, cy, base + (12f + 28f * level) * d * (0.6f + 0.4f * breathe), paint)
                paint.color = rgb or 0x66000000
                c.drawCircle(cx, cy, base + (5f + 14f * level) * d, paint)
            }

            paint.style = Paint.Style.FILL
            paint.color = color
            c.drawCircle(cx, cy, base, paint)

            // biểu tượng micro màu trắng
            paint.color = 0xFFFFFFFF.toInt()
            body.set(cx - 11f * d, cy - 28f * d, cx + 11f * d, cy + 8f * d)
            c.drawRoundRect(body, 11f * d, 11f * d, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3.5f * d
            paint.strokeCap = Paint.Cap.ROUND
            arc.set(cx - 18f * d, cy - 16f * d, cx + 18f * d, cy + 20f * d)
            c.drawArc(arc, 0f, 180f, false, paint)
            c.drawLine(cx, cy + 20f * d, cx, cy + 30f * d, paint)
            c.drawLine(cx - 10f * d, cy + 30f * d, cx + 10f * d, cy + 30f * d, paint)
        }
    }
}
