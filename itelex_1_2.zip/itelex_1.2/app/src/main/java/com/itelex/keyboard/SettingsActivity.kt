package com.itelex.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Cài đặt giao diện, gợi ý từ và bảng gõ tắt kiểu UniKey. */
class SettingsActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    private fun label(value: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = value
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(if (isDark) 0xFFF2F2F7.toInt() else Color.BLACK)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(10), 0, dp(4))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scaleStart = KeyboardSettings.keyScale(this)
        val liftStart = KeyboardSettings.keyLift(this)
        val widthStart = KeyboardSettings.keyWidth(this)
        val suggestStart = KeyboardSettings.isSuggestEnabled(this)
        val macroStart = KeyboardSettings.isMacroEnabled(this)
        val smartStart = KeyboardSettings.isSmartTransformEnabled(this)
        val macroManager = MacroManager(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(if (isDark) 0xFF1C1C1E.toInt() else 0xFFF7F7FA.toInt())
        }
        root.addView(label("Cài đặt bàn phím", 27f, true))
        root.addView(label("Điều chỉnh giao diện iOS 18, gợi ý từ và bảng gõ tắt.", 14f).apply {
            setTextColor(if (isDark) 0xFFB8B8BE.toInt() else 0xFF666666.toInt())
        })

        // Công tắc Bật/Tắt Smart Transform (Biến đổi thông minh kiểu Laban Key)
        val smartSwitch = Switch(this).apply {
            text = "Smart Transform (sửa lỗi gõ nhanh & trượt phím)"
            isChecked = smartStart
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(if (isDark) 0xFFF2F2F7.toInt() else Color.BLACK)
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(smartSwitch)

        // Công tắc Bật/Tắt thanh gợi ý từ
        val suggestSwitch = Switch(this).apply {
            text = "Thanh gợi ý từ thông minh"
            isChecked = suggestStart
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(if (isDark) 0xFFF2F2F7.toInt() else Color.BLACK)
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(suggestSwitch)

        // Công tắc Bật/Tắt gõ tắt
        val macroSwitch = Switch(this).apply {
            text = "Cho phép gõ tắt (như UniKey)"
            isChecked = macroStart
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(if (isDark) 0xFFF2F2F7.toInt() else Color.BLACK)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(macroSwitch)

        // Khu vực quản lý bảng gõ tắt
        root.addView(label("Bảng gõ tắt (ví dụ: vn -> Việt Nam)", 16f, true))
        val macroListBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }

        fun renderMacros() {
            macroListBox.removeAllViews()
            val items = macroManager.getAll()
            if (items.isEmpty()) {
                macroListBox.addView(label("Chưa có từ gõ tắt nào.", 13f).apply {
                    setTextColor(if (isDark) 0xFFB8B8BE.toInt() else 0xFF666666.toInt())
                })
                return
            }
            for ((shortcut, expansion) in items) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                val tv = TextView(this).apply {
                    text = "$shortcut  →  $expansion"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    setTextColor(if (isDark) 0xFFF2F2F7.toInt() else Color.BLACK)
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                }
                val delBtn = Button(this).apply {
                    text = "Xóa"
                    setAllCaps(false)
                    setOnClickListener {
                        macroManager.remove(shortcut)
                        renderMacros()
                    }
                }
                row.addView(tv)
                row.addView(delBtn)
                macroListBox.addView(row)
            }
        }
        renderMacros()

        val addMacroBtn = Button(this).apply {
            text = "+ Thêm từ gõ tắt mới"
            setAllCaps(false)
            setOnClickListener {
                val box = LinearLayout(this@SettingsActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(20), dp(12), dp(20), dp(4))
                }
                val inputShortcut = EditText(this@SettingsActivity).apply {
                    hint = "Từ viết tắt (ví dụ: hnay)"
                }
                val inputExpansion = EditText(this@SettingsActivity).apply {
                    hint = "Cụm từ thay thế (ví dụ: hôm nay)"
                }
                box.addView(inputShortcut)
                box.addView(inputExpansion)

                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("Thêm từ gõ tắt")
                    .setView(box)
                    .setPositiveButton("Lưu") { _, _ ->
                        val sc = inputShortcut.text.toString().trim()
                        val ex = inputExpansion.text.toString().trim()
                        if (sc.isNotEmpty() && ex.isNotEmpty()) {
                            macroManager.save(sc, ex)
                            renderMacros()
                            Toast.makeText(this@SettingsActivity, "Đã lưu: $sc → $ex", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Hủy", null)
                    .show()
            }
        }
        root.addView(addMacroBtn)
        root.addView(macroListBox)

        // Thanh chỉnh độ nâng
        val liftValue = label("Độ nâng bàn phím: ${liftStart} dp", 17f, true)
        root.addView(liftValue)
        val liftSeek = SeekBar(this).apply {
            max = 48
            progress = liftStart
        }
        root.addView(liftSeek)
        root.addView(label("Tăng giá trị để bàn phím được đẩy lên cao hơn, tạo khoảng trống bên dưới.", 13f).apply {
            setTextColor(if (isDark) 0xFFB8B8BE.toInt() else 0xFF666666.toInt())
        })

        // Thanh chỉnh kích thước phím
        val scaleValue = label("Kích thước phím: ${((scaleStart * 100).toInt())}%", 17f, true)
        root.addView(scaleValue)
        val scaleSeek = SeekBar(this).apply {
            max = 55
            progress = ((scaleStart - 0.85f) * 100).toInt().coerceIn(0, 55)
        }
        root.addView(scaleSeek)
        root.addView(label("Từ 85% đến 140%. Tăng kích thước sẽ làm phím cao hơn và chữ trên phím lớn hơn.", 13f).apply {
            setTextColor(if (isDark) 0xFFB8B8BE.toInt() else 0xFF666666.toInt())
        })

        // Thanh chỉnh độ rộng phím
        fun widthText(level: Int) =
            "Độ rộng phím: mức $level/10" + if (level == 0) " (mặc định)" else ""
        val widthValue = label(widthText(widthStart), 17f, true)
        root.addView(widthValue)
        val widthSeek = SeekBar(this).apply {
            max = 10
            progress = widthStart.coerceIn(0, 10)
        }
        root.addView(widthSeek)
        root.addView(label("Tăng mức để phím rộng hơn: thu hẹp lề hai bên và khe giữa các phím. Mức 10 là rộng nhất.", 13f).apply {
            setTextColor(if (isDark) 0xFFB8B8BE.toInt() else 0xFF666666.toInt())
        })

        fun save() {
            val lift = liftSeek.progress
            val scale = 0.85f + scaleSeek.progress / 100f
            val width = widthSeek.progress
            KeyboardSettings.save(
                this, scale, lift,
                suggestSwitch.isChecked, macroSwitch.isChecked, smartSwitch.isChecked, width
            )
            liftValue.text = "Độ nâng bàn phím: $lift dp"
            scaleValue.text = "Kích thước phím: ${(scale * 100).toInt()}%"
            widthValue.text = widthText(width)
        }

        smartSwitch.setOnCheckedChangeListener { _, _ -> save() }
        suggestSwitch.setOnCheckedChangeListener { _, _ -> save() }
        macroSwitch.setOnCheckedChangeListener { _, _ -> save() }

        liftSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = save()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        scaleSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = save()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        widthSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = save()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        root.addView(Button(this).apply {
            text = "Đặt lại mặc định"
            setAllCaps(false)
            setOnClickListener {
                liftSeek.progress = 0
                scaleSeek.progress = 15
                widthSeek.progress = 0
                smartSwitch.isChecked = true
                suggestSwitch.isChecked = true
                macroSwitch.isChecked = true
                save()
            }
        }.also { it.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) } })
        root.addView(Button(this).apply {
            text = "Xong"
            setAllCaps(false)
            setOnClickListener { finish() }
        })
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }
}
