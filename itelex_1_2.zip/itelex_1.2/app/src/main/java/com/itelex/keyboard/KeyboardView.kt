package com.itelex.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets

/**
 * Bàn phím QWERTY song ngữ phong cách iOS 18.
 * Hàng dưới: 123 -> Quả địa cầu -> Space -> Return.
 * Thanh trên cùng: nút bật/tắt gợi ý (trên phím Q) - 3 ô gợi ý - nút micro (trên phím P).
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(s: String, alt: Boolean)
        fun onDelete()
        fun onSpace()
        fun onReturn()
        fun onGlobeClick()
        fun onPickIme()
        fun onSuggestion(s: String)
        fun onMic()
        fun onToggleSuggest()
    }

    enum class Page { LETTERS, NUMBERS, SYMBOLS }

    private enum class KT { CHAR, SHIFT, DELETE, MODE, SYM, GLOBE, MIC, SPACE, RETURN }

    private class Key(val type: KT, val label: String, val weight: Float = 1f) {
        val rect = RectF()
    }

    private class Ptr {
        var key: Key? = null
        var slot = -1
        var longRun: Runnable? = null
        var repRun: Runnable? = null
        var alts: List<String>? = null
        var aRect: RectF? = null
        var aIdx = 0
        var longFired = false
        /** 0 = không phải nút trên thanh, 1 = bật/tắt gợi ý, 2 = micro */
        var bar = 0
    }

    // ------------------------------------------------------------- trạng thái

    var listener: Listener? = null

    var page: Page = Page.LETTERS
        set(value) {
            field = value
            buildKeys()
            invalidate()
        }

    /** 0 = thường, 1 = hoa một lần, 2 = Caps Lock */
    var shiftState: Int = 0
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var viMode: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    var returnLabel: String = ""
        set(value) {
            field = value
            invalidate()
        }

    var returnBlue: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var suggestions: List<String> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    /** true = hiện gợi ý từ. Thanh trên cùng luôn có để chứa nút micro và nút bật/tắt gợi ý. */
    var suggestOn: Boolean = true
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    // ---------------------------------------------------------------- kích thước chuẩn iOS 18

    private val d = context.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private val barH get() = dp(42f)
    private val topPad = dp(8f)
    private var keyScale = 1.0f
    private var liftDp = 0
    private val keyH get() = dp(43f * keyScale)
    private val rowGap get() = dp(11f * keyScale)
    private val bottomLift get() = dp(liftDp.toFloat())
    /** Khoảng cách tối thiểu 0,5 cm (5 mm) từ phím dưới cùng tới đáy màn hình. */
    private val minBottom = maxOf(
        dp(8f),
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_MM, 5f, context.resources.displayMetrics)
    )
    private var navInset = 0f
    private val bottomPad get() = maxOf(minBottom, navInset)
    /** Mức độ rộng phím 0..10: càng cao thì lề hai bên và khe ngang giữa các phím càng hẹp, phím càng rộng. */
    private var widthLevel = 0
    private val widthT get() = widthLevel / 10f
    private val side get() = dp(3.5f * (1f - widthT))
    private val gap get() = dp((6f - 3f * widthT) * keyScale)

    /** Tổng khoảng trống phía dưới hàng phím cuối (đã gồm tối thiểu 0,5 cm và độ nâng). */
    fun bottomSpace(): Float = bottomPad + bottomLift

    /** Cập nhật tùy chỉnh từ màn hình cài đặt. */
    fun applyUserSettings(scale: Float, lift: Int, suggestEnabled: Boolean = true, keyWidth: Int = widthLevel) {
        keyScale = scale.coerceIn(0.85f, 1.4f)
        liftDp = lift.coerceIn(0, 48)
        widthLevel = keyWidth.coerceIn(0, 10)
        suggestOn = suggestEnabled
        layoutKeys()
        requestLayout()
        invalidate()
    }

    private var rows: List<List<Key>> = emptyList()
    private val toggleRect = RectF()
    private val micRect = RectF()
    private var rowPad = FloatArray(4)
    private val ptrs = HashMap<Int, Ptr>()
    private var lastShiftTap = 0L
    private var dark = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val handler = Handler(Looper.getMainLooper())
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        buildKeys()
        setOnApplyWindowInsetsListener { _, insets ->
            val b = bottomInset(insets).toFloat()
            if (b != navInset) {
                navInset = b
                requestLayout()
            }
            insets
        }
    }

    @Suppress("DEPRECATION")
    private fun bottomInset(insets: WindowInsets): Int =
        if (Build.VERSION.SDK_INT >= 30) {
            insets.getInsets(WindowInsets.Type.navigationBars()).bottom
        } else {
            insets.systemWindowInsetBottom
        }

    // ----------------------------------------------------------------- bố cục iOS 18

    private fun charKeys(s: String, w: Float = 1f) = s.map { Key(KT.CHAR, it.toString(), w) }

    private fun buildKeys() {
        // Hàng dưới cùng: 123 -> Quả địa cầu -> Space -> Return (micro nằm trên phím P)
        val bottom = listOf(
            Key(KT.MODE, if (page == Page.LETTERS) "123" else "ABC", 1.5f),
            Key(KT.GLOBE, "", 1.4f),
            Key(KT.SPACE, "", 5.1f),
            Key(KT.RETURN, "", 2.3f)
        )
        when (page) {
            Page.LETTERS -> {
                rows = listOf(
                    charKeys("qwertyuiop"),
                    charKeys("asdfghjkl"),
                    listOf(Key(KT.SHIFT, "", 1.35f)) + charKeys("zxcvbnm") + Key(KT.DELETE, "", 1.35f),
                    bottom
                )
                rowPad = floatArrayOf(0f, 0.5f, 0f, 0f)
            }
            Page.NUMBERS -> {
                rows = listOf(
                    charKeys("1234567890"),
                    charKeys("-/:;()₫&@"),
                    listOf(Key(KT.SYM, "#+=", 1.35f)) + charKeys(".,?!'", 1.46f) + Key(KT.DELETE, "", 1.35f),
                    bottom
                )
                rowPad = FloatArray(4)
            }
            Page.SYMBOLS -> {
                rows = listOf(
                    charKeys("[]{}#%^*+="),
                    charKeys("_\\|~<>€£¥•"),
                    listOf(Key(KT.SYM, "123", 1.35f)) + charKeys(".,?!'", 1.46f) + Key(KT.DELETE, "", 1.35f),
                    bottom
                )
                rowPad = FloatArray(4)
            }
        }
        layoutKeys()
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        if (w <= 0f) return
        for ((ri, row) in rows.withIndex()) {
            val pad = rowPad[ri]
            val total = row.sumOf { it.weight.toDouble() }.toFloat() + 2 * pad
            val unit = (w - 2 * side - gap * (row.size - 1)) / total
            var x = side + pad * unit
            val top = barH + topPad + ri * (keyH + rowGap)
            for (k in row) {
                val kw = k.weight * unit
                k.rect.set(x, top, x + kw, top + keyH)
                x += kw + gap
            }
        }
        // Nút trên thanh trên cùng: bật/tắt gợi ý nằm trên phím đầu hàng 1 (Q), micro nằm trên phím cuối hàng 1 (P)
        rows.firstOrNull()?.let { first ->
            val q = first.first().rect
            val p = first.last().rect
            toggleRect.set(q.left, dp(4f), q.right, barH - dp(4f))
            micRect.set(p.left, dp(4f), p.right, barH - dp(4f))
        }
    }

    private fun slotsLeft() = toggleRect.right + gap / 2f
    private fun slotsRight() = micRect.left - gap / 2f

    /** Ô gợi ý (0..2) tại vị trí x, -1 nếu ngoài vùng hoặc gợi ý đang tắt. */
    private fun slotAt(x: Float): Int {
        val l = slotsLeft()
        val r = slotsRight()
        if (!suggestOn || r <= l || x < l || x > r) return -1
        return ((x - l) / ((r - l) / 3f)).toInt().coerceIn(0, 2)
    }

    /** 1 = nút bật/tắt gợi ý, 2 = micro, 0 = vùng gợi ý. */
    private fun barButtonAt(x: Float): Int = when {
        x < slotsLeft() -> 1
        x > slotsRight() -> 2
        else -> 0
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = barH + topPad + 4 * keyH + 3 * rowGap + bottomPad + bottomLift
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h.toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacksAndMessages(null)
        ptrs.clear()
    }

    // ----------------------------------------------------------------- vẽ chuẩn iOS 18

    private fun col(light: Long, darkC: Long): Int = (if (dark) darkC else light).toInt()

    private fun shown(k: Key): String =
        if (page == Page.LETTERS && shiftState != 0) k.label.uppercase() else k.label

    private fun drawCentered(c: Canvas, s: String, cx: Float, cy: Float) {
        val fm = text.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, text)
    }

    override fun onDraw(c: Canvas) {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        c.drawColor(col(0xFFD1D3D9, 0xFF1C1C1E))
        drawBar(c)

        val pressed = ptrs.values.mapNotNull { if (it.alts == null && it.slot < 0) it.key else null }
        for (row in rows) for (k in row) drawKey(c, k, pressed.contains(k))

        for (p in ptrs.values) {
            val k = p.key
            if (p.alts != null) drawAccents(c, p)
            else if (k != null && k.type == KT.CHAR && p.slot < 0) drawBalloon(c, k)
        }
    }

    private fun drawBar(c: Canvas) {
        val l = slotsLeft()
        val r = slotsRight()
        val slotW = (r - l) / 3f
        val ink = col(0xFF1C1C1E, 0xFFF2F2F7)

        // Nút bật/tắt gợi ý (trên phím Q) và micro (trên phím P)
        fill.color = col(0x18000000, 0x26FFFFFF)
        if (ptrs.values.any { it.bar == 1 }) c.drawRoundRect(toggleRect, dp(6f), dp(6f), fill)
        if (ptrs.values.any { it.bar == 2 }) c.drawRoundRect(micRect, dp(6f), dp(6f), fill)
        drawSuggestToggleIcon(c, toggleRect.centerX(), toggleRect.centerY(), ink)
        drawMicIcon(c, micRect.centerX(), micRect.centerY(), ink)

        if (!suggestOn || r <= l) return

        for (i in 0 until 3) {
            if (ptrs.values.any { it.slot == i }) {
                fill.color = col(0x18000000, 0x26FFFFFF)
                c.drawRoundRect(
                    l + slotW * i + dp(2f), dp(4f),
                    l + slotW * (i + 1) - dp(2f), barH - dp(4f),
                    dp(6f), dp(6f), fill
                )
            }
        }

        text.color = ink
        text.textSize = dp(16f)
        for (i in 0 until 3) {
            val suggestion = suggestions.getOrNull(i) ?: continue
            val shownText = TextUtils.ellipsize(suggestion, text, slotW - dp(12f), TextUtils.TruncateAt.END).toString()
            drawCentered(c, shownText, l + slotW * i + slotW / 2f, barH / 2f)
        }

        fill.color = col(0x28000000, 0x33FFFFFF)
        for (i in 1..2) {
            c.drawRect(l + slotW * i - dp(0.5f), dp(10f), l + slotW * i + dp(0.5f), barH - dp(10f), fill)
        }
    }

    /** Biểu tượng "Aa": sáng = gợi ý đang bật, mờ + gạch chéo = đang tắt. */
    private fun drawSuggestToggleIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val shade = if (suggestOn) ink else (ink and 0x00FFFFFF) or 0x80000000.toInt()
        text.color = shade
        text.textSize = dp(15f)
        drawCentered(c, "Aa", cx, cy)
        if (!suggestOn) {
            val s = dp(1f)
            line.color = shade
            line.strokeWidth = dp(1.6f)
            line.style = Paint.Style.STROKE
            c.drawLine(cx - 10f * s, cy + 9f * s, cx + 10f * s, cy - 9f * s, line)
        }
    }

    private fun drawKey(c: Canvas, k: Key, pressed: Boolean) {
        val r = k.rect
        val letter = col(0xFFFFFFFF, 0xFF464649)
        val special = col(0xFFABB0B9, 0xFF2C2C2E)
        val shadow = col(0xFF898A8D, 0xFF0E0E10)
        val ink = col(0xFF000000, 0xFFFFFFFF)
        val blue = returnBlue && k.type == KT.RETURN

        val f = when {
            blue -> if (pressed) 0xFF0051A8.toInt() else 0xFF007AFF.toInt()
            k.type == KT.CHAR || k.type == KT.SPACE -> if (pressed) special else letter
            k.type == KT.SHIFT && shiftState > 0 -> if (pressed) special else letter
            else -> if (pressed) letter else special
        }
        // Bo góc 5dp chuẩn iOS 18 và chân phím 1.2dp
        val rad = dp(5f)
        fill.color = shadow
        c.drawRoundRect(r.left, r.top + dp(1.2f), r.right, r.bottom + dp(1.2f), rad, rad, fill)
        fill.color = f
        c.drawRoundRect(r, rad, rad, fill)

        val cx = r.centerX()
        val cy = r.centerY()
        when (k.type) {
            KT.CHAR -> {
                text.color = ink
                text.textSize = dp(23.5f * keyScale)
                drawCentered(c, shown(k), cx, cy - dp(0.5f))
            }
            KT.MODE, KT.SYM -> {
                text.color = ink
                text.textSize = dp(15.5f * keyScale)
                drawCentered(c, k.label, cx, cy)
            }
            KT.SPACE -> {
                text.color = ink
                text.textSize = dp(15f * keyScale)
                drawCentered(c, if (viMode) "Tiếng Việt" else "space", cx, cy)
            }
            KT.RETURN -> {
                if (returnLabel.isEmpty()) {
                    drawReturnIcon(c, cx, cy, ink)
                } else {
                    text.color = if (blue) 0xFFFFFFFF.toInt() else ink
                    text.textSize = dp(15.5f * keyScale)
                    drawCentered(c, returnLabel, cx, cy)
                }
            }
            KT.SHIFT -> drawShiftIcon(c, cx, cy, ink)
            KT.DELETE -> drawDeleteIcon(c, cx, cy, ink)
            KT.GLOBE -> drawGlobeIcon(c, cx, cy, ink)
            KT.MIC -> drawMicIcon(c, cx, cy, ink)
        }
    }

    private fun drawMicIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val s = dp(1f)
        line.color = ink
        line.strokeWidth = dp(1.55f)
        line.style = Paint.Style.STROKE
        c.drawRoundRect(RectF(cx - 3.2f * s, cy - 9.5f * s, cx + 3.2f * s, cy + 1.5f * s), 3.2f * s, 3.2f * s, line)
        c.drawArc(RectF(cx - 6.5f * s, cy - 5.5f * s, cx + 6.5f * s, cy + 6.5f * s), 0f, 180f, false, line)
        c.drawLine(cx, cy + 6.5f * s, cx, cy + 10.5f * s, line)
        c.drawLine(cx - 3.8f * s, cy + 10.5f * s, cx + 3.8f * s, cy + 10.5f * s, line)
    }

    private fun drawShiftIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val s = dp(1f)
        val p = Path().apply {
            moveTo(cx, cy - 9.5f * s)
            lineTo(cx + 9.5f * s, cy)
            lineTo(cx + 4f * s, cy)
            lineTo(cx + 4f * s, cy + 7f * s)
            lineTo(cx - 4f * s, cy + 7f * s)
            lineTo(cx - 4f * s, cy)
            lineTo(cx - 9.5f * s, cy)
            close()
        }
        line.color = ink
        line.strokeWidth = dp(1.55f)
        line.style = if (shiftState > 0) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
        c.drawPath(p, line)
        line.style = Paint.Style.STROKE
        if (shiftState == 2) c.drawLine(cx - 4f * s, cy + 10.5f * s, cx + 4f * s, cy + 10.5f * s, line)
    }

    private fun drawDeleteIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val s = dp(1f)
        val p = Path().apply {
            moveTo(cx - 10.5f * s, cy)
            lineTo(cx - 4f * s, cy - 7.5f * s)
            lineTo(cx + 10.5f * s, cy - 7.5f * s)
            lineTo(cx + 10.5f * s, cy + 7.5f * s)
            lineTo(cx - 4f * s, cy + 7.5f * s)
            close()
        }
        line.color = ink
        line.strokeWidth = dp(1.55f)
        line.style = Paint.Style.STROKE
        c.drawPath(p, line)
        c.drawLine(cx + 1f * s, cy - 3f * s, cx + 6.5f * s, cy + 3f * s, line)
        c.drawLine(cx + 6.5f * s, cy - 3f * s, cx + 1f * s, cy + 3f * s, line)
    }

    private fun drawGlobeIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val s = dp(1f)
        line.color = ink
        line.strokeWidth = dp(1.45f)
        line.style = Paint.Style.STROKE
        c.drawCircle(cx, cy, 8.8f * s, line)
        c.drawOval(cx - 4f * s, cy - 8.8f * s, cx + 4f * s, cy + 8.8f * s, line)
        c.drawLine(cx - 8.8f * s, cy, cx + 8.8f * s, cy, line)
        c.drawLine(cx - 7.3f * s, cy - 4.3f * s, cx + 7.3f * s, cy - 4.3f * s, line)
        c.drawLine(cx - 7.3f * s, cy + 4.3f * s, cx + 7.3f * s, cy + 4.3f * s, line)
    }

    private fun drawReturnIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val s = dp(1f)
        line.color = ink
        line.strokeWidth = dp(1.7f)
        line.style = Paint.Style.STROKE
        val body = Path().apply {
            moveTo(cx + 8f * s, cy - 6f * s)
            lineTo(cx + 8f * s, cy + 2f * s)
            lineTo(cx - 8f * s, cy + 2f * s)
        }
        val head = Path().apply {
            moveTo(cx - 3f * s, cy - 3f * s)
            lineTo(cx - 8f * s, cy + 2f * s)
            lineTo(cx - 3f * s, cy + 7f * s)
        }
        c.drawPath(body, line)
        c.drawPath(head, line)
    }

    private fun drawBalloon(c: Canvas, k: Key) {
        val r = k.rect
        val letter = col(0xFFFFFFFF, 0xFF636366)
        val ink = col(0xFF000000, 0xFFFFFFFF)
        val bw = r.width() * 1.48f
        val left = (r.centerX() - bw / 2f).coerceIn(dp(2f), width - dp(2f) - bw)
        val top = r.top - keyH * 1.08f
        val upper = RectF(left, top, left + bw, r.top + dp(8f))
        val neck = RectF(r.left, r.top, r.right, r.bottom)
        val rad = dp(9f)

        fill.color = letter
        fill.setShadowLayer(dp(4f), 0f, dp(1f), 0x66000000)
        c.drawRoundRect(upper, rad, rad, fill)
        c.drawRoundRect(neck, dp(5f), dp(5f), fill)
        fill.clearShadowLayer()
        c.drawRoundRect(upper, rad, rad, fill)
        c.drawRoundRect(neck, dp(5f), dp(5f), fill)

        text.color = ink
        text.textSize = dp(34f)
        drawCentered(c, shown(k), upper.centerX(), (top + r.top) / 2f)
    }

    private fun accentRect(k: Key, n: Int): RectF {
        val cw = minOf(dp(40f), (width - dp(4f)) / n)
        val h = dp(52f)
        val w = cw * n
        val left = (k.rect.centerX() - w / 2f).coerceIn(dp(2f), width - dp(2f) - w)
        val top = (k.rect.top - h - dp(6f)).coerceAtLeast(dp(2f))
        return RectF(left, top, left + w, top + h)
    }

    private fun drawAccents(c: Canvas, p: Ptr) {
        val r = p.aRect ?: return
        val alts = p.alts ?: return
        val letter = col(0xFFFFFFFF, 0xFF636366)
        val ink = col(0xFF000000, 0xFFFFFFFF)
        val n = alts.size
        val cw = r.width() / n
        val rad = dp(10f)

        fill.color = letter
        fill.setShadowLayer(dp(4f), 0f, dp(1f), 0x66000000)
        c.drawRoundRect(r, rad, rad, fill)
        fill.clearShadowLayer()
        c.drawRoundRect(r, rad, rad, fill)

        text.textSize = dp(24f)
        for (i in 0 until n) {
            if (i == p.aIdx) {
                fill.color = 0xFF007AFF.toInt()
                c.drawRoundRect(
                    r.left + cw * i + dp(2f), r.top + dp(4f),
                    r.left + cw * (i + 1) - dp(2f), r.bottom - dp(4f),
                    dp(7f), dp(7f), fill
                )
                text.color = 0xFFFFFFFF.toInt()
            } else {
                text.color = ink
            }
            drawCentered(c, alts[i], r.left + cw * i + cw / 2f, r.centerY())
        }
    }

    // ------------------------------------------------------------------ chạm

    private fun hit(x: Float, y: Float): Key? {
        if (rows.isEmpty()) return null
        val top0 = barH + topPad
        if (y < top0) return null
        // Vùng đệm 0,5 cm phía dưới hàng phím cuối: không nhận chạm để không bấm nhầm phím
        if (y > top0 + rows.size * keyH + (rows.size - 1) * rowGap + rowGap) return null
        val ri = ((y - top0 + rowGap / 2f) / (keyH + rowGap)).toInt().coerceIn(0, rows.size - 1)
        val row = rows[ri]
        val half = gap / 2f
        for (k in row) {
            if (x >= k.rect.left - half && x <= k.rect.right + half) return k
        }
        return if (x < row.first().rect.left) row.first() else row.last()
    }

    private fun altsFor(k: Key): List<String> {
        val list = (if (page == Page.LETTERS) LETTER_ALTS[k.label] else SYMBOL_ALTS[k.label])
            ?: return emptyList()
        return if (page == Page.LETTERS && shiftState != 0) list.map { it.uppercase() } else list
    }

    private fun feedback() {
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
    }

    private fun cancelRuns(p: Ptr) {
        p.longRun?.let { handler.removeCallbacks(it) }
        p.repRun?.let { handler.removeCallbacks(it) }
        p.longRun = null
        p.repRun = null
    }

    private fun armLong(p: Ptr) {
        p.longRun?.let { handler.removeCallbacks(it) }
        val r = Runnable { onLong(p) }
        p.longRun = r
        handler.postDelayed(r, 380L)
    }

    private fun onLong(p: Ptr) {
        val k = p.key ?: return
        when (k.type) {
            KT.GLOBE -> {
                p.longFired = true
                listener?.onPickIme()
            }
            KT.CHAR -> {
                val alts = altsFor(k)
                if (alts.isNotEmpty()) {
                    p.alts = alts
                    p.aIdx = 0
                    p.aRect = accentRect(k, alts.size)
                    p.longFired = true
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    invalidate()
                }
            }
            else -> {}
        }
    }

    private fun down(id: Int, x: Float, y: Float) {
        val p = Ptr()
        if (y < barH) {
            val b = barButtonAt(x)
            if (b != 0) {
                p.bar = b
                feedback()
            } else {
                p.slot = slotAt(x)
                if (p.slot < 0) return
            }
            ptrs[id] = p
            invalidate()
            return
        }
        val k = hit(x, y) ?: return
        p.key = k
        ptrs[id] = p
        feedback()
        if (k.type == KT.DELETE) {
            listener?.onDelete()
            val rep = object : Runnable {
                override fun run() {
                    listener?.onDelete()
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    handler.postDelayed(this, 55L)
                }
            }
            p.repRun = rep
            handler.postDelayed(rep, 400L)
        } else {
            armLong(p)
        }
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        if (p.slot >= 0 || p.bar != 0) return
        val r = p.aRect
        val alts = p.alts
        if (r != null && alts != null) {
            val idx = ((x - r.left) / (r.width() / alts.size)).toInt().coerceIn(0, alts.size - 1)
            if (idx != p.aIdx) {
                p.aIdx = idx
                invalidate()
            }
            return
        }
        val k = p.key ?: return
        if (p.longFired || k.type == KT.DELETE) return
        val nk = hit(x, y)
        if (nk != null && nk !== k && nk.type != KT.DELETE) {
            p.key = nk
            armLong(p)
            invalidate()
        }
    }

    private fun up(id: Int, x: Float) {
        val p = ptrs.remove(id) ?: return
        cancelRuns(p)

        if (p.bar != 0) {
            if (barButtonAt(x) == p.bar) {
                if (p.bar == 1) listener?.onToggleSuggest() else listener?.onMic()
            }
            invalidate()
            return
        }
        if (p.slot >= 0) {
            if (suggestOn && slotAt(x) == p.slot) {
                suggestions.getOrNull(p.slot)?.let { listener?.onSuggestion(it) }
            }
            invalidate()
            return
        }
        val alts = p.alts
        if (alts != null) {
            alts.getOrNull(p.aIdx)?.let {
                if (shiftState == 1) shiftState = 0
                listener?.onText(it, true)
            }
            invalidate()
            return
        }
        val k = p.key
        if (k == null || p.longFired) {
            invalidate()
            return
        }
        when (k.type) {
            KT.CHAR -> {
                val s = shown(k)
                if (page == Page.LETTERS && shiftState == 1) shiftState = 0
                listener?.onText(s, false)
            }
            KT.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                shiftState = when {
                    shiftState == 2 -> 0
                    shiftState == 1 && now - lastShiftTap < 350L -> 2
                    shiftState == 1 -> 0
                    else -> 1
                }
                lastShiftTap = now
            }
            KT.MODE -> page = if (page == Page.LETTERS) Page.NUMBERS else Page.LETTERS
            KT.SYM -> page = if (page == Page.NUMBERS) Page.SYMBOLS else Page.NUMBERS
            KT.GLOBE -> listener?.onGlobeClick()
            KT.MIC -> listener?.onMic()
            KT.SPACE -> listener?.onSpace()
            KT.RETURN -> listener?.onReturn()
            KT.DELETE -> {}
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                up(e.getPointerId(i), e.getX(i))
            }
            MotionEvent.ACTION_CANCEL -> {
                ptrs.values.forEach { cancelRuns(it) }
                ptrs.clear()
                invalidate()
            }
        }
        return true
    }

    private companion object {
        val LETTER_ALTS = mapOf(
            "a" to listOf("à", "á", "ả", "ã", "ạ", "â", "ă"),
            "e" to listOf("è", "é", "ẻ", "ẽ", "ẹ", "ê"),
            "i" to listOf("ì", "í", "ỉ", "ĩ", "ị"),
            "o" to listOf("ò", "ó", "ỏ", "õ", "ọ", "ô", "ơ"),
            "u" to listOf("ù", "ú", "ủ", "ũ", "ụ", "ư"),
            "y" to listOf("ỳ", "ý", "ỷ", "ỹ", "ỵ"),
            "d" to listOf("đ")
        )
        val SYMBOL_ALTS = mapOf(
            "0" to listOf("°"),
            "-" to listOf("–", "—", "•"),
            "₫" to listOf("$", "€", "£", "¥"),
            "&" to listOf("§"),
            "\"" to listOf("“", "”", "„", "«", "»"),
            "." to listOf("…"),
            "?" to listOf("¿"),
            "!" to listOf("¡"),
            "'" to listOf("‘", "’", "`"),
            "%" to listOf("‰")
        )
    }
}
