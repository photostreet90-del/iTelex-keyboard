package com.itelex.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.text.TextPaint
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.OverScroller

/** Bảng emoji kiểu iOS: lưới cuộn dọc, tiêu đề từng nhóm, thanh nhóm ở dưới. */
class EmojiView(context: Context) : View(context) {

    interface Listener {
        fun onEmoji(s: String)
        fun onBack()
        fun onDelete()
    }

    var listener: Listener? = null

    private class Cat(val icon: String, val name: String, val items: List<String>)

    private class Row(val header: String?, val items: List<String>) {
        var y = 0f
        var h = 0f
    }

    private val d = context.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private val barH = dp(44f)
    private val cellH = dp(46f)
    private val headH = dp(32f)
    private val sideW = dp(56f)

    /** Khoảng đệm phía dưới (khớp bàn phím chữ, tối thiểu 0,5 cm) để thanh ABC không sát đáy màn hình. */
    var bottomPad = 0f
        set(value) {
            if (field != value) {
                field = value
                rebuild()
                invalidate()
            }
        }

    private val prefs = context.getSharedPreferences("itelex_emoji", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val scroller = OverScroller(context)

    private var base: List<Cat>? = null
    private var cats: List<Cat> = emptyList()
    private var rows: List<Row> = emptyList()
    private var catRow = IntArray(0)
    private var totalH = 0f
    private var contentH = 0f
    private var scrollY = 0f
    private var cols = 8
    private var cellW = 1f
    private var dark = false

    private var barTouch = false
    private var barTarget = -1
    private var delRun: Runnable? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    // ------------------------------------------------------------ dữ liệu

    private fun cp(v: Int) = String(Character.toChars(v))

    /** Nhận số đơn hoặc dải số (mã Unicode). */
    private fun range(vararg r: Any): List<String> {
        val out = ArrayList<String>()
        for (x in r) {
            when (x) {
                is Int -> out.add(cp(x))
                is IntRange -> for (v in x) out.add(cp(v))
            }
        }
        return out
    }

    /** Emoji cần thêm ký tự chọn kiểu hiển thị (VS16) để ra dạng màu. */
    private fun vs(vararg v: Int): List<String> = v.map { cp(it) + "️" }

    private fun buildBase(): List<Cat> {
        val probe = Paint()
        fun ok(l: List<String>) = LinkedHashSet(l).filter { probe.hasGlyph(it) }

        return listOf(
            Cat(cp(0x1F600), "Mặt cười & cảm xúc", ok(
                range(0x1F600..0x1F644, 0x1F910..0x1F92F, 0x1F970..0x1F97A, 0x1F47B..0x1F47F, 0x1F4A9, 0x1F480) +
                    vs(0x263A, 0x2639)
            )),
            Cat(cp(0x1F44B), "Con người", ok(
                range(0x1F446..0x1F450, 0x1F645..0x1F64F, 0x1F466..0x1F478, 0x1F4AA, 0x1F918..0x1F91F, 0x1F930..0x1F939) +
                    vs(0x270C, 0x261D, 0x270B, 0x1F590) + range(0x270A, 0x270D, 0x1F595, 0x1F596)
            )),
            Cat(cp(0x1F436), "Động vật & thiên nhiên", ok(
                range(0x1F400..0x1F43E, 0x1F980..0x1F9AE, 0x1F331..0x1F344, 0x1F30D..0x1F320) +
                    vs(0x2600, 0x2601, 0x2614, 0x26A1, 0x2744, 0x26C4)
            )),
            Cat(cp(0x1F354), "Đồ ăn & thức uống", ok(
                range(0x1F345..0x1F37F, 0x1F32D..0x1F32F, 0x1F950..0x1F96B, 0x1F9C0..0x1F9C2) + vs(0x2615)
            )),
            Cat(cp(0x26BD), "Hoạt động", ok(
                range(0x1F383..0x1F393, 0x1F3A0..0x1F3CA, 0x1F3CF..0x1F3D3, 0x1F94A..0x1F94F) +
                    vs(0x26BD, 0x26BE, 0x26F3)
            )),
            Cat(cp(0x1F697), "Du lịch & địa điểm", ok(
                range(0x1F680..0x1F6C5, 0x1F3E0..0x1F3F0, 0x1F5FB..0x1F5FF) + vs(0x2708, 0x26F5)
            )),
            Cat(cp(0x1F4A1), "Đồ vật", ok(
                range(0x1F4A1, 0x1F4B0..0x1F4FD, 0x1F50B..0x1F52E, 0x1F9E0..0x1F9FF) +
                    vs(0x260E, 0x2709, 0x270F, 0x2702, 0x231A, 0x23F0, 0x231B)
            )),
            Cat("❤️", "Biểu tượng", ok(
                vs(0x2764) + range(0x1F493..0x1F49F, 0x1F5A4, 0x1F90D..0x1F90F, 0x1F4AF, 0x1F4A2..0x1F4A8, 0x1F500..0x1F53D) +
                    vs(0x2705, 0x274C, 0x2757, 0x2753, 0x2728, 0x267B, 0x2714, 0x2716, 0x2795, 0x2796,
                        0x27A1, 0x2B05, 0x2B06, 0x2B07, 0x26A0, 0x2B55)
            ))
        ).filter { it.items.isNotEmpty() }
    }

    private fun recents(): List<String> =
        (prefs.getString("recent", "") ?: "").split(' ').filter { it.isNotEmpty() }

    private fun addRecent(s: String) {
        val list = recents().toMutableList()
        list.remove(s)
        list.add(0, s)
        prefs.edit().putString("recent", list.take(32).joinToString(" ")).apply()
    }

    /** Gọi mỗi lần mở bảng: nạp lại mục "Gần đây" và cuộn về đầu. */
    fun refresh() {
        val b = base ?: buildBase().also { base = it }
        val rec = recents()
        cats = if (rec.isEmpty()) b else listOf(Cat(cp(0x1F558), "Gần đây", rec)) + b
        scroller.forceFinished(true)
        scrollY = 0f
        rebuild()
        invalidate()
    }

    private fun rebuild() {
        if (width <= 0) return
        contentH = height - barH - bottomPad
        cols = maxOf(5, (width / dp(44f)).toInt())
        cellW = width.toFloat() / cols

        val list = ArrayList<Row>()
        val idx = IntArray(cats.size)
        for ((ci, c) in cats.withIndex()) {
            idx[ci] = list.size
            list.add(Row(c.name, emptyList()))
            c.items.chunked(cols).forEach { list.add(Row(null, it)) }
        }
        var y = 0f
        for (r in list) {
            r.y = y
            r.h = if (r.header != null) headH else cellH
            y += r.h
        }
        rows = list
        catRow = idx
        totalH = y
        scrollY = scrollY.coerceIn(0f, maxScroll())
    }

    private fun maxScroll() = maxOf(0f, totalH - contentH)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------------ vẽ

    private fun col(light: Long, darkC: Long): Int = (if (dark) darkC else light).toInt()

    private fun drawCentered(c: Canvas, s: String, cx: Float, cy: Float) {
        val fm = text.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, text)
    }

    private fun currentCat(): Int {
        var cur = 0
        for (i in catRow.indices) if (rows[catRow[i]].y <= scrollY + 2f) cur = i
        return cur
    }

    override fun onDraw(c: Canvas) {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        c.drawColor(col(0xFFD3D5DB, 0xFF2A2A2C))

        c.save()
        c.clipRect(0f, 0f, width.toFloat(), contentH)
        for (r in rows) {
            val top = r.y - scrollY
            if (top + r.h < 0f) continue
            if (top > contentH) break
            if (r.header != null) {
                text.textAlign = Paint.Align.LEFT
                text.color = col(0xFF6D6D72, 0xFF9A9A9F)
                text.textSize = dp(12f)
                text.isFakeBoldText = true
                val fm = text.fontMetrics
                c.drawText(r.header.uppercase(), dp(12f), top + r.h / 2f - (fm.ascent + fm.descent) / 2f + dp(4f), text)
                text.isFakeBoldText = false
                text.textAlign = Paint.Align.CENTER
            } else {
                text.color = 0xFF000000.toInt()
                text.textSize = dp(28f)
                for ((i, e) in r.items.withIndex()) {
                    drawCentered(c, e, cellW * i + cellW / 2f, top + r.h / 2f)
                }
            }
        }
        c.restore()
        drawBar(c)
    }

    private fun drawBar(c: Canvas) {
        val top = contentH
        val ink = col(0xFF000000, 0xFFFFFFFF)

        fill.color = col(0xFFC4C7CE, 0xFF1F1F21)
        c.drawRect(0f, top, width.toFloat(), height.toFloat(), fill)
        fill.color = col(0x22000000, 0x33FFFFFF)
        c.drawRect(0f, top, width.toFloat(), top + 1f, fill)

        val cy = top + barH / 2f

        // Nút ABC
        text.color = ink
        text.textSize = dp(16f)
        drawCentered(c, "ABC", sideW / 2f, cy)

        // Các nhóm
        val n = cats.size
        if (n > 0) {
            val w = (width - 2 * sideW) / n
            val cur = currentCat()
            for (i in 0 until n) {
                val cx = sideW + w * i + w / 2f
                if (i == cur) {
                    fill.color = col(0x26000000, 0x33FFFFFF)
                    val rr = minOf(dp(18f), w / 2f)
                    c.drawRoundRect(RectF(cx - rr, cy - dp(17f), cx + rr, cy + dp(17f)), dp(9f), dp(9f), fill)
                }
                text.color = ink
                text.textSize = dp(20f)
                drawCentered(c, cats[i].icon, cx, cy)
            }
        }

        // Nút xóa
        drawDeleteIcon(c, width - sideW / 2f, cy, ink)
    }

    private fun drawDeleteIcon(c: Canvas, cx: Float, cy: Float, ink: Int) {
        val s = dp(1f)
        val p = Path().apply {
            moveTo(cx - 11 * s, cy)
            lineTo(cx - 4 * s, cy - 8 * s)
            lineTo(cx + 11 * s, cy - 8 * s)
            lineTo(cx + 11 * s, cy + 8 * s)
            lineTo(cx - 4 * s, cy + 8 * s)
            close()
        }
        line.color = ink
        line.strokeWidth = dp(1.6f)
        c.drawPath(p, line)
        c.drawLine(cx + 1 * s, cy - 3 * s, cx + 7 * s, cy + 3 * s, line)
        c.drawLine(cx + 7 * s, cy - 3 * s, cx + 1 * s, cy + 3 * s, line)
    }

    // ---------------------------------------------------------------- chạm

    private val gd = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            scroller.forceFinished(true)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            scrollY = (scrollY + dy).coerceIn(0f, maxScroll())
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            scroller.fling(0, scrollY.toInt(), 0, (-vy).toInt(), 0, 0, 0, maxScroll().toInt())
            postInvalidateOnAnimation()
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            tapContent(e.x, e.y)
            return true
        }
    })

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollY = scroller.currY.toFloat().coerceIn(0f, maxScroll())
            postInvalidateOnAnimation()
        }
    }

    private fun tapContent(x: Float, y: Float) {
        if (y >= contentH) return
        val ay = y + scrollY
        for (r in rows) {
            if (ay >= r.y && ay < r.y + r.h) {
                if (r.header != null) return
                val e = r.items.getOrNull((x / cellW).toInt()) ?: return
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                addRecent(e)
                listener?.onEmoji(e)
                return
            }
        }
    }

    private fun targetAt(x: Float): Int {
        if (x < sideW) return -2
        if (x > width - sideW) return -3
        val n = cats.size
        if (n == 0) return -1
        val w = (width - 2 * sideW) / n
        return ((x - sideW) / w).toInt().coerceIn(0, n - 1)
    }

    private fun stopRepeat() {
        delRun?.let { handler.removeCallbacks(it) }
        delRun = null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            barTouch = e.y >= contentH && e.y <= contentH + barH
            if (barTouch) {
                barTarget = targetAt(e.x)
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (barTarget == -3) {
                    listener?.onDelete()
                    val rep = object : Runnable {
                        override fun run() {
                            listener?.onDelete()
                            handler.postDelayed(this, 55L)
                        }
                    }
                    delRun = rep
                    handler.postDelayed(rep, 400L)
                }
            }
        }
        if (barTouch) {
            when (e.actionMasked) {
                MotionEvent.ACTION_UP -> {
                    stopRepeat()
                    val t = targetAt(e.x)
                    if (t == barTarget) {
                        if (t == -2) listener?.onBack()
                        else if (t >= 0) jumpTo(t)
                    }
                    barTouch = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    stopRepeat()
                    barTouch = false
                }
            }
            return true
        }
        return gd.onTouchEvent(e)
    }

    private fun jumpTo(cat: Int) {
        if (cat !in catRow.indices) return
        scroller.forceFinished(true)
        scrollY = rows[catRow[cat]].y.coerceIn(0f, maxScroll())
        invalidate()
    }
}
