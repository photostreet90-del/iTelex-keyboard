package com.itelex.keyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Màn hình hướng dẫn bật bàn phím + ô gõ thử. */
class MainActivity : Activity() {

    private lateinit var status: TextView

    private companion object {
        const val DONATE_BANK = "Techcombank"
        const val DONATE_NAME = "HA MANH DUONG"
        const val DONATE_ACCOUNT = "19072541099011"
        const val DONATE_ACCOUNT_SHOWN = "1907 2541 0990 11"
    }

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, bold: Boolean = false, color: Int? = null) =
        TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color ?: if (isDark) 0xFFF2F2F7.toInt() else Color.BLACK)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, px(8), 0, px(4))
        }

    private fun button(text: String, onClick: () -> Unit) =
        Button(this).apply {
            this.text = text
            setAllCaps(false)
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(32), px(24), px(24))
            setBackgroundColor(if (isDark) 0xFF1C1C1E.toInt() else 0xFFF7F7FA.toInt())
        }

        root.addView(label("iTelex", 34f, bold = true))
        root.addView(label("Bàn phím kiểu iOS 18 cho Android, gõ tiếng Việt Telex.", 15f, color = if (isDark) 0xFFB8B8BE.toInt() else 0xFF555555.toInt()))

        root.addView(button("Cài đặt giao diện bàn phím") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })

        root.addView(label("Bước 1 — Bật bàn phím", 17f, bold = true))
        root.addView(button("Mở cài đặt bàn phím") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })

        root.addView(label("Bước 2 — Chọn iTelex để dùng", 17f, bold = true))
        root.addView(button("Chọn bàn phím") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        status = label("", 14f, color = 0xFF007AFF.toInt())
        status.gravity = Gravity.START
        root.addView(status)

        root.addView(label("Gõ thử", 17f, bold = true))
        root.addView(EditText(this).apply {
            hint = "Chạm vào đây rồi gõ thử, ví dụ: Vieejt Nam"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            gravity = Gravity.TOP
        })

        root.addView(label(
            "Mẹo: chạm biểu tượng quả địa cầu để đổi Tiếng Việt / English, " +
                "chạm lần nữa để mở emoji, nhấn giữ để đổi sang bàn phím khác. " +
                "Nút micro nằm trên phím P, nút Aa trên phím Q để bật/tắt gợi ý từ. Nhấn giữ nguyên âm để chọn dấu. " +
                "Chạm hai lần phím mũi tên để bật Caps Lock. Chạm hai lần phím cách để chấm câu.",
            14f, color = if (isDark) 0xFFB8B8BE.toInt() else 0xFF555555.toInt()
        ))

        addDonateSection(root)

        setContentView(ScrollView(this).apply {
            fitsSystemWindows = true
            isFillViewport = true
            addView(root)
        })
    }

    /** Phần ủng hộ tác giả qua tài khoản ngân hàng / mã QR, dòng chữ nhỏ "Buy me a coffee". */
    private fun addDonateSection(root: LinearLayout) {
        val soft = if (isDark) 0xFFB8B8BE.toInt() else 0xFF555555.toInt()

        root.addView(View(this).apply {
            setBackgroundColor(if (isDark) 0x33FFFFFF else 0x1F000000)
        }, LinearLayout.LayoutParams(-1, px(1)).apply { topMargin = px(24); bottomMargin = px(12) })

        root.addView(label("☕ Buy me a coffee", 12f, color = soft).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.donate_qr)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Mã QR chuyển khoản $DONATE_BANK"
        }, LinearLayout.LayoutParams(px(230), px(281)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = px(4)
        })

        root.addView(label(DONATE_NAME, 14f, bold = true).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(label("$DONATE_BANK · $DONATE_ACCOUNT_SHOWN", 14f, color = soft).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(button("Sao chép số tài khoản") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Số tài khoản", DONATE_ACCOUNT))
            Toast.makeText(this, "Đã sao chép số tài khoản", Toast.LENGTH_SHORT).show()
        })
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val selected = current.startsWith("$packageName/")
        status.text = "Bước 1: " + (if (enabled) "✅ đã bật" else "⬜ chưa bật") +
            "\nBước 2: " + (if (selected) "✅ đang dùng iTelex" else "⬜ chưa chọn")
    }
}
